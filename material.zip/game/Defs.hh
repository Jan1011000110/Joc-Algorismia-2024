#define GAME_NAME "HarryPotter"
#define VERSION   "1.0"
